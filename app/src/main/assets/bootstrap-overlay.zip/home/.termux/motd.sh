#!/data/data/com.termux/files/usr/bin/bash
cat /data/data/com.termux/files/usr/etc/motd
echo -e "  \e[1mTermux version:\e[0m ${TERMUX_VERSION-Unknown}"
echo
