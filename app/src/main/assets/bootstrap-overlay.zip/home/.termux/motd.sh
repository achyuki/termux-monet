#!/data/data/com.termux/files/usr/bin/bash

# Setup TERMUX_APP_PACKAGE_MANAGER
source "/data/data/com.termux/files/usr/bin/termux-setup-package-manager" || exit 1

cat /data/data/com.termux/files/usr/etc/motd
echo -e "  \e[1mTermux version:\e[0m ${TERMUX_VERSION-Unknown}"
echo
